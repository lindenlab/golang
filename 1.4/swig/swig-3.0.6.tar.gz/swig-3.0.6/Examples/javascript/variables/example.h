/* File: example.h */

typedef struct {
  int x,y;
} Point;

