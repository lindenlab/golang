extern char *s;
extern int x;

class Sync {
	public:
		int x;
		char *s;
		void printer(void);
};
